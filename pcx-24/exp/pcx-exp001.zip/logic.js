document.addEventListener('DOMContentLoaded', () => {
    if (sessionStorage.getItem('mflExpPopupClosed') !== 'true') {
        setTimeout(showPopup, 3000);
    }
});

function showPopup() {
    const isMobile = window.innerWidth < 1074;
    const popupFile = isMobile ? 'mobilePopUp.html' : 'desktopPopUp.html';

    fetch(popupFile)
        .then(response => response.text())
        .then(html => {
            document.body.insertAdjacentHTML('afterbegin', html);
            document.querySelector('.custom-popup-overlay').style.display = 'flex';
            addCloseEvent();
        })
        .catch(error => console.error('Error loading popup:', error));
}

function addCloseEvent() {
    const closeButton = document.querySelector('.custom-popup .close-button');
    const overlay = document.querySelector('.custom-popup-overlay');

    closeButton.addEventListener('click', () => {
        document.querySelector('.custom-popup').style.display = 'none';
        if (overlay) overlay.style.display = 'none';
        sessionStorage.setItem('mflExpPopupClosed', 'true');
    });

    if (overlay) {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                document.querySelector('.custom-popup').style.display = 'none';
                overlay.style.display = 'none';
                sessionStorage.setItem('mflExpPopupClosed', 'true');
            }
        });
    }
}
